package com.capstone.Nutrition_Rec;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NutritionRecApplicationTests {

	@Test
	void contextLoads() {
	}

}
