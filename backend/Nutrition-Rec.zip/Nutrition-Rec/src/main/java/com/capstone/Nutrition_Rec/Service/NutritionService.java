package com.capstone.Nutrition_Rec.Service;

import com.capstone.Nutrition_Rec.Model.NutritionData;
import com.capstone.Nutrition_Rec.Repository.NutritionRepository;
import com.capstone.Nutrition_Rec.dto.NutritionRequestDto;
import com.capstone.Nutrition_Rec.dto.NutritionResponseDto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.*;

@Service
public class NutritionService {

    @Autowired
    private RestTemplate restTemplate;

    @Autowired
    private NutritionRepository nutritionRepository;

    private static final String API_URL = "https://api.edamam.com/api/nutrition-data";


        // Prepare response DTO
        public NutritionResponseDto saveNutritionData(NutritionRequestDto requestDto) {
            String appId = "7c0847b5";
            String appKey = "298965f796d46e7677b52f5698c608a8";
            String url = String.format("%s?app_id=%s&app_key=%s&ingr=%s", API_URL, appId, appKey, requestDto.getIngredient());

            // Call the external API to fetch nutrition info
            String response = restTemplate.getForObject(url, String.class);

            // Save the NutritionData to MongoDB with the current timestamp
            NutritionData data = new NutritionData();
            data.setIngredient(requestDto.getIngredient());
            data.setNutritionInfo(response);
            data.setUserId(requestDto.getUserId());
            data.setTimestamp(new Date()); // Set the current date and time

            nutritionRepository.save(data);

            // Prepare the response DTO
            NutritionResponseDto responseDto = new NutritionResponseDto();
            responseDto.setIngredient(requestDto.getIngredient());
            responseDto.setNutritionInfo(response);

            return responseDto;
        }

    public List<NutritionResponseDto> getNutritions(String userId) {
        // Retrieve all nutrition data from MongoDB based on userId
        List<NutritionData> dataList = nutritionRepository.findAllByUserId(userId);

        // Initialize the list of response DTOs
        List<NutritionResponseDto> responseDtos = new ArrayList<>();

        Date today = new Date();
        int totalCaloriesGainedToday = 0;

        // Check if the dataList is empty or null
        if (dataList == null || dataList.isEmpty()) {
            NutritionResponseDto responseDto = new NutritionResponseDto();
            responseDto.setIngredient("No data available");
            responseDto.setNutritionInfo(String.valueOf(new HashMap<>()));
            responseDtos.add(responseDto);
            return responseDtos;
        }

        // If data is found, filter by today's date and sum calories
        for (NutritionData data : dataList) {
            if (isSameDay(today, data.getGainedDate())) {
                // Parse nutrition info and add up the calories for today
                String nutritionInfo = data.getNutritionInfo();
                // Assuming the nutrition info contains calorie data in JSON, extract the calories
                int caloriesGained = extractCaloriesFromNutritionInfo(nutritionInfo);
                totalCaloriesGainedToday += caloriesGained;
            }
        }

        // Add the total calories gained for today to the response
        NutritionResponseDto responseDto = new NutritionResponseDto();
        responseDto.setIngredient("Total Calories Gained Today");
        responseDto.setNutritionInfo(String.valueOf(totalCaloriesGainedToday));
        responseDtos.add(responseDto);

        return responseDtos;
    }

    // Utility function to check if two dates are on the same day
    private boolean isSameDay(Date date1, Date date2) {
        Calendar cal1 = Calendar.getInstance();
        Calendar cal2 = Calendar.getInstance();
        cal1.setTime(date1);
        cal2.setTime(date2);
        return cal1.get(Calendar.YEAR) == cal2.get(Calendar.YEAR) &&
                cal1.get(Calendar.DAY_OF_YEAR) == cal2.get(Calendar.DAY_OF_YEAR);
    }


}
