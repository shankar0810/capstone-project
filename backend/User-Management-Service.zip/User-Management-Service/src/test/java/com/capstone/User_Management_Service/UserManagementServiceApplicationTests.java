package com.capstone.User_Management_Service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserManagementServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
